<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location:login.php');
    die();
}

?>


<?php

include 'include/header.php';

?>
<!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
        <!-- sidebar -->
        <?php
        include 'include/sidebar.php';

        ?>
        <!-- / sidebar -->

        <!-- Layout container -->
        <div class="layout-page">
            <!-- Navbar -->
            <?php
            include 'include/nav.php';
            ?>
            <!-- / Navbar -->

            <!-- Content wrapper -->
            <div class="content-wrapper">
                <!-- Content -->

                <div class="container mt-4">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="text-end">
                                    <button type="button" class="btn btn-success  m-2" data-bs-toggle="modal" data-bs-target="#chargemodal">
                                        Add charge
                                    </button>
                                </div>
                                <h5 class="card-header">charge Table</h5>
                                <div class="table-responsive text-nowrap" id="chargeTable">
                                    <table class="table">
                                        <thead class="table-light">

                                        </thead>

                                        <tbody>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- / Content -->



                <div class="modal fade" id="chargemodal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalCenterTitle">charge Modal</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form id="chargeform">
                                    <input type="hidden" name="update_id" id="update_id">
                                    <div class="row">

                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <select name="month_iddd" id="month_iddd" class="form-control month" required>
                                                    <option value="0">Select month</option>

                                                </select>
                                            </div>

                                        </div>

                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <select name="year" id="year" class="form-control">
                                                    <?php
                                                    $start_year = 2024; // set the starting year 
                                                    $current_year = date('Y'); // get the current year 
                                                    for ($year = $current_year; $year >= $start_year; $year--) {
                                                        echo "<option value=\"$year\">$year</option>";
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                            <!-- <input type="number" min="1900" max="2099" step="1" value="2023" name="year" id="year" class="form-control mt-2" require> -->
                                        </div>

                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <input type="text" name="description" id="description" placeholder="Description" class="form-control validate" required>
                                            </div>

                                        </div>

                                        <div class="col-sm-6 mt-4">
                                            <div class="form-group mt-3">
                                                <input name="user_id" id="user_id" value="<?php echo $_SESSION['username'] ?>" class="form-control" readonly>

                                            </div>

                                        </div>
                                        <div class="col-sm-6 mt-4">
                                            <div class="form-group mt-3">
                                                <select name="Acount_id" id="Acount_id" class="form-control" required>

                                                    <option value="0">select Account</option>
                                                </select>
                                            </div>

                                        </div>
                                    </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                    Close
                                </button>
                                <button type="submit" class="btn btn-primary">Save changes</button>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>



                <!-- Footer -->

                <?php

                include 'include/footer.php';
                ?>
                <!-- / Footer -->

                <div class="content-backdrop fade"></div>
            </div>
            <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
    </div>

    <!-- Overlay -->
    <div class="layout-overlay layout-menu-toggle"></div>
</div>
<!-- / Layout wrapper -->

<?php
include 'include/script.php';
?>