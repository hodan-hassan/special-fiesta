<?php
header("content-type: application/json");
include '../config/conn.php';
// $action = $_POST['action'];

function register_medicalrecords($conn)
{
    extract($_POST);
    $data = array();
    $query = "INSERT INTO medicalrecords(pet_id, Notes, medicine_id, quantity,price)
     values('$pet_id', '$Notes', '$medicine_id', '$quantity', '$price')";

    $result = $conn->query($query);


    if ($result) {


        $data = array("status" => true, "data" => "medicalrecords has been Registered");
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function read_all_medicalrecords($conn)
{
    $data = array();
    $array_data = array();
    $query = "SELECT mr.RecordID,p.pet_name,mr.Notes,m.medicine_name,mr.quantity,mr.price,mr.status,mr.date from medicalrecords mr JOIN pets p on mr.pet_id=p.pet_id JOIN medicines m on mr.medicine_id=m.medicine_id ";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


// function read_all_sell_statement($conn)
// {
//     extract($_POST);
//     $data = array();
//     $array_data = array();
//     $query = "CALL read_sell_statement('$tellphone')";
//     $result = $conn->query($query);


//     if ($result) {
//         while ($row = $result->fetch_assoc()) {
//             $array_data[] = $row;
//         }
//         $data = array("status" => true, "data" => $array_data);
//     } else {
//         $data = array("status" => false, "data" => $conn->error);
//     }

//     echo json_encode($data);
// }

function read_all_medicine_price($conn)
{
    extract($_POST);
    $data = array();
    $array_data = array();
    $query = "CALL read_all_medicine_price('$medicine_id')";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}



if (isset($_POST['action'])) {
    $action = $_POST['action'];
    $action($conn);
} else {
    echo json_encode(array("status" => false, "data" => "Action Required....."));
}
