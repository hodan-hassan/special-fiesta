<?php
header("content-type: application/json");
include '../config/conn.php';
// $action = $_POST['action'];

function register_apointments($conn)
{
    extract($_POST);
    $data = array();
    $query = "INSERT INTO appointments(pet_id, apointmentdate, purpose)
     values('$pets_id', '$apointmentdate', '$purpose')";

    $result = $conn->query($query);


    if ($result) {


        $data = array("status" => true, "data" => "New Apointment has been Registered");
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function read_all_apointments($conn)
{
    $data = array();
    $array_data = array();
    $query = "SELECT ap.AppointmentID,o.owner_name,p.pet_name,ap.apointmentdate,ap.purpose,ap.date from appointments ap JOIN pets p on ap.pet_id=p.pet_id join owners o on p.owner_id=o.owner_id";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


function read_paid_pets($conn)
{
    $data = array();
    $array_data = array();
    $query = "SELECT p.pet_id,p.pet_name from medicalrecords mr JOIN pets p on mr.pet_id=p.pet_id WHERE mr.status='paid';";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function get_apointment_info($conn)
{
    extract($_POST);
    $data = array();
    $array_data = array();
    $query = "SELECT *FROM appointments where AppointmentID= '$AppointmentID'";
    $result = $conn->query($query);


    if ($result) {
        $row = $result->fetch_assoc();

        $data = array("status" => true, "data" => $row);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


function update_apointment($conn)
{
    extract($_POST);
    $data = array();
    $query = "UPDATE appointments set pet_id = '$pets_id', apointmentdate= '$apointmentdate',  purpose = '$purpose' WHERE AppointmentID = '$AppointmentID'";
    $result = $conn->query($query);


    if ($result) {

        $data = array("status" => true, "data" => "Apointments has been Updated");
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}



if (isset($_POST['action'])) {
    $action = $_POST['action'];
    $action($conn);
} else {
    echo json_encode(array("status" => false, "data" => "Action Required....."));
}
