<?php
header("content-type: application/json");
include '../config/conn.php';
// $action = $_POST['action'];

function register_charge($conn)
{
    extract($_POST);
    $data = array();
    $query = "CALL charge_months('$month_iddd', '$year', '$description', '$Acount_id', '$user_id')";

    $result = $conn->query($query);


    if ($result) {

        $row = $result->fetch_assoc();
        if ($row['msg'] == 'Deny') {
            $data = array("status" => false, "data" => "Insufficient Balance");
        } elseif ($row['msg'] == 'Registered') {
            $data = array("status" => true, "data" => "Transaction successfully ✅");
        } elseif ($row['msg'] == 'NOt') {
            $data = array("status" => false, "data" => "Horay Ayaa loogu dalacay lacagta bishaan ❌");
        }
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function read_all_charge($conn)
{
    $data = array();
    $array_data = array();
    $query = "SELECT ch.charge_id as ID, concat(e.frist_name, ' ', e.last_name) as Employee,ch.Amount as salary,m.month_name as month,ch.year,ch.description,ac.bank_name,ch.user_id as userName,ch.status,ch.date FROM charge ch JOIN employe e on ch.employe_id=e.employe_id JOIN job_title j on ch.title_id=j.title_id JOIN month m on ch.month_id=m.month_id JOIN account ac on ch.Account_id=ac.Account_id order by ID";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


function read_all_monthes($conn)
{
    $data = array();
    $array_data = array();
    $query = "SELECT * from month";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


if (isset($_POST['action'])) {
    $action = $_POST['action'];
    $action($conn);
} else {
    echo json_encode(array("status" => false, "data" => "Action Required....."));
}
