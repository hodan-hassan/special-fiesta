<?php


header("content-type: application/json");
include '../config/conn.php';
// $action = $_POST['action'];

function register_pets($conn)
{
    extract($_POST);
    $data = array();
    $query = "INSERT INTO pets(owner_id, pet_name, gender, type_id, age)
     values('$owner_id', '$pet_name', '$gender', '$type_id', '$age')";

    $result = $conn->query($query);


    if ($result) {


        $data = array("status" => true, "data" => "pets has been Registered");
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function read_all_pets($conn)
{
    $data = array();
    $array_data = array();
    $query = "SELECT p.pet_id,o.owner_name,p.pet_name,p.gender,a.Name as animal_Type,p.age,p.date from pets p JOIN owners o on p.owner_id=o.owner_id JOIN animaltype a on p.type_id=a.type_id";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}




function read_pets_statement($conn)
{
    extract($_POST);
    $data = array();
    $array_data = array();
    $query = "CALL read_pets_statement('$pets_name')";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


function get_pets_info($conn)
{
    extract($_POST);
    $data = array();
    $array_data = array();
    $query = "SELECT *FROM pets where pet_id= '$pet_id'";
    $result = $conn->query($query);


    if ($result) {
        $row = $result->fetch_assoc();

        $data = array("status" => true, "data" => $row);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


function update_pets($conn)
{
    extract($_POST);
    $data = array();
    $query = "UPDATE pets set owner_id = '$owner_id', pet_name= '$pet_name',  gender = '$gender', type_id= '$type_id', age= '$age' WHERE pet_id = '$pet_id'";
    $result = $conn->query($query);


    if ($result) {

        $data = array("status" => true, "data" => "pets has been Updated");
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


function Delete_pets($conn)
{
    extract($_POST);
    $data = array();
    $array_data = array();
    $query = "DELETE FROM pets where pet_id= '$pet_id'";
    $result = $conn->query($query);


    if ($result) {


        $data = array("status" => true, "data" => "pets has been Deleted");
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

if (isset($_POST['action'])) {
    $action = $_POST['action'];
    $action($conn);
} else {
    echo json_encode(array("status" => false, "data" => "Action Required....."));
}
