<?php
header("content-type: application/json");
include '../config/conn.php';
// $action = $_POST['action'];

function register_owner($conn)
{
    extract($_POST);
    $data = array();
    $query = "INSERT INTO owners(owner_name, phone, adress)
     values('$owner_name', '$phone', '$adress')";

    $result = $conn->query($query);


    if ($result) {


        $data = array("status" => true, "data" => "New owner has been Registered");
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function read_all_owner($conn)
{
    $data = array();
    $array_data = array();
    $query = "select * from owners";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


function get_owner_info($conn)
{
    extract($_POST);
    $data = array();
    $array_data = array();
    $query = "SELECT *FROM owners where owner_id= '$owner_id'";
    $result = $conn->query($query);


    if ($result) {
        $row = $result->fetch_assoc();

        $data = array("status" => true, "data" => $row);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


function update_owner($conn)
{
    extract($_POST);
    $data = array();
    $query = "UPDATE owners set owner_name = '$owner_name', phone= '$phone',  adress = '$adress' WHERE owner_id = '$owner_id'";
    $result = $conn->query($query);


    if ($result) {

        $data = array("status" => true, "data" => "owner has been Updated");
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function Delete_owners($conn)
{
    extract($_POST);
    $data = array();
    $array_data = array();
    $query = "DELETE FROM owners where owner_id= '$owner_id'";
    $result = $conn->query($query);


    if ($result) {


        $data = array("status" => true, "data" => "owner has been Deleted");
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

if (isset($_POST['action'])) {
    $action = $_POST['action'];
    $action($conn);
} else {
    echo json_encode(array("status" => false, "data" => "Action Required....."));
}
