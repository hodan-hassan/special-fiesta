<?php
header("content-type: application/json");
include '../config/conn.php';
// $action = $_POST['action'];

function register_medicine($conn)
{
    extract($_POST);
    $data = array();
    $query = "INSERT INTO medicines(medicine_name, manufacturer, price)
     values('$medicine_name', '$manufacturer', '$price')";

    $result = $conn->query($query);


    if ($result) {


        $data = array("status" => true, "data" => "New medicine has been Registered");
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function read_all_medicine($conn)
{
    $data = array();
    $array_data = array();
    $query = "select * from medicines";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


function get_medicine_info($conn)
{
    extract($_POST);
    $data = array();
    $array_data = array();
    $query = "SELECT *FROM medicines where medicine_id= '$medicine_id'";
    $result = $conn->query($query);


    if ($result) {
        $row = $result->fetch_assoc();

        $data = array("status" => true, "data" => $row);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


function update_medicine($conn)
{
    extract($_POST);
    $data = array();
    $query = "UPDATE medicines set medicine_name = '$medicine_name', manufacturer= '$manufacturer',  price = '$price' WHERE medicine_id = '$medicine_id'";
    $result = $conn->query($query);


    if ($result) {

        $data = array("status" => true, "data" => "medicine has been Updated");
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function Delete_medicine($conn)
{
    extract($_POST);
    $data = array();
    $array_data = array();
    $query = "DELETE FROM medicines where medicine_id= '$medicine_id'";
    $result = $conn->query($query);


    if ($result) {


        $data = array("status" => true, "data" => "Account has been Deleted");
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}




if (isset($_POST['action'])) {
    $action = $_POST['action'];
    $action($conn);
} else {
    echo json_encode(array("status" => false, "data" => "Action Required....."));
}
