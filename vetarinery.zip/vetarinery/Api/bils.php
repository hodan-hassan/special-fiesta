<?php
header("content-type: application/json");
include '..//config/conn.php';
// $action = $_POST['action'];


function read_employe_salary($conn)
{
    extract($_POST);
    $data = array();
    $array_data = array();
    $query = "SELECT SUM(Amount) as salary from charge WHERE employe_id=('$employee') and status='pending'";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function register_bills($conn)
{
    extract($_POST);
    $data = array();
    $query = "INSERT INTO `bills`(`employe_id`, `Amount`, `user`)
    VALUES('$employee', '$amount', '$user')";
    $result = $conn->query($query);

    if ($result) {

        $data = array("status" => true, "data" => "Transaction Successfully");
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }


    echo json_encode($data);
}



function read_bills($conn)
{
    extract($_POST);
    $data = array();
    $array_data = array();
    $query = "SELECT b.bill_id,concat(e.frist_name, ' ', e.last_name) as employe_name,b.Amount as salary,b.user,b.date from bills b JOIN employe e on b.employe_id=e.employe_id";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


function read_bills_statement($conn)
{
    extract($_POST);
    $data = array();
    $array_data = array();
    $query = "CALL bill_repot('$month')";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


function read_all_employeeee($conn)
{
    $data = array();
    $array_data = array();
    $query = "SELECT Distinct e.employe_id,concat(e.frist_name, ' ', e.last_name) as employe_name from charge ch JOIN employe e on ch.employe_id=e.employe_id  WHERE ch.status='pending'";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

if (isset($_POST['action'])) {
    $action = $_POST['action'];
    $action($conn);
} else {
    echo json_encode(array("status" => false, "data" => "Action Required....."));
}
