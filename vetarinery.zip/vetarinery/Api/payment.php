<?php
header("content-type: application/json");
include '../config/conn.php';
// $action = $_POST['action'];


function register_payment($conn)
{
    extract($_POST);
    $data = array();
    $query = "INSERT INTO payment(pet_id, amount, Account_id, p_method_id)
     values('$pet_iddd', '$amount', '$Accountt_id', '$p_method_id')";

    $result = $conn->query($query);


    if ($result) {


        $data = array("status" => true, "data" => "Transaction has been completed");
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}



function read_amount($conn)
{
    extract($_POST);
    $data = array();
    $array_data = array();
    $query = "CALL read_amount('$pet_id')";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function read_pets($conn)
{
    $data = array();
    $array_data = array();
    $query = "SELECT p.pet_id,p.pet_name from medicalrecords mr JOIN pets p on mr.pet_id=p.pet_id WHERE mr.status='pending';";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


function read_all_payment_statement($conn)
{
    extract($_POST);
    $data = array();
    $array_data = array();
    $query = "CALL payment_statement('$tellphone')";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function read_all_payment($conn)
{
    $data = array();
    $array_data = array();
    $query = "SELECT p.payment_id,o.owner_name,pe.pet_name,p.amount, ac.bank_name,pm.name as methodName,p.date from payment p JOIN pets pe on p.pet_id=pe.pet_id JOIN owners o on pe.owner_id=o.owner_id JOIN account ac on p.Account_id=ac.Account_id JOIN payment_method pm on p.p_method_id=pm.p_method_id";
    $result = $conn->query($query);


    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $array_data[] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    } else {
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}



if (isset($_POST['action'])) {
    $action = $_POST['action'];
    $action($conn);
} else {
    echo json_encode(array("status" => false, "data" => "Action Required....."));
}
