-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2024 at 07:46 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `veterinary`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `bill_repot` (IN `_month_name` VARCHAR(100))   BEGIN
SELECT concat(e.frist_name, ' ', e.last_name) as employe_name, j.position as Title,ch.Amount as salary,m.month_name as month,ch.year,ch.description,ch.user_id as user from charge ch JOIN employe e on ch.employe_id=e.employe_id JOIN job_title j on ch.title_id=j.title_id
JOIN month m on ch.month_id=m.month_id  WHERE m.month_name=_month_name and ch.status='paid';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `charge_months` (IN `_month_id` INT, IN `_year` VARCHAR(100), IN `_description` TEXT, IN `_Account_id` INT, IN `_user_id` VARCHAR(100))   BEGIN
if(read_salary() > read_acount_balance(_Account_id))THEN
SELECT "Deny" as msg;
else
INSERT IGNORE INTO `charge`(`employe_id`, `title_id`, `Amount`, `Account_id`, `month_id`, `year`, `description`, `user_id`,`date`)
 SELECT e.employe_id,j.title_id,j.salary,_Account_id,_month_id,_year,_description,_user_id,
CURRENT_DATE from employe e JOIN job_title  j on e.title_id=j.title_id;
IF(row_count()>0)THEN
SELECT "Registered" as msg;
ELSE
SELECT "NOt" as msg;
END IF;    
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `forget` (IN `_username` VARCHAR(50), IN `_password` INT)   BEGIN

if EXISTS(SELECT * FROM users WHERE users.username = _username)THEN	

UPDATE `users` SET password = MD5(_password) WHERE username = _username;
 
 SELECT 'success' Msg;

ELSE

SELECT 'deny' Msg;

end if;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `login_procedure` (IN `_username` VARCHAR(100), IN `_password` VARCHAR(100))   BEGIN


if EXISTS(SELECT * FROM users WHERE users.username = _username and users.password = MD5(_password))THEN	


if EXISTS(SELECT * FROM users WHERE users.username = _username and 	users.status = 'Active')THEN
 
SELECT * FROM users where users.username = _username;

ELSE

SELECT 'Locked' msg;

end if;
ELSE


SELECT 'Deny' msg;

END if;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `payment_statement` (IN `_tellphone` INT)   BEGIN

if(_tellphone = '0000-00-00')THEN
SELECT p.payment_id,o.owner_name,o.phone as owner_number,pe.pet_name,p.amount, ac.bank_name,pm.name as methodName,p.date from payment p JOIN pets pe on p.pet_id=pe.pet_id JOIN owners o on pe.owner_id=o.owner_id JOIN account ac on p.Account_id=ac.Account_id JOIN payment_method pm on p.p_method_id=pm.p_method_id;
ELSE
SELECT p.payment_id,o.owner_name,o.phone as owner_number,pe.pet_name,p.amount, ac.bank_name,pm.name as methodName,p.date from payment p JOIN pets pe on p.pet_id=pe.pet_id JOIN owners o on pe.owner_id=o.owner_id JOIN account ac on p.Account_id=ac.Account_id JOIN payment_method pm on p.p_method_id=pm.p_method_id WHERE o.phone=_tellphone;
END if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `read_all_employe` ()   BEGIN
SELECT e.employe_id,concat(e.frist_name, ' ', e.last_name) as employe_name, e.phone,e.city,e.state,b.address as branch,j.position,j.salary from employe e JOIN branch b on e.branch_id=b.branch_id JOIN job_title j on e.title_id=j.title_id ORDER BY e.employe_id;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `read_all_medicine_price` (IN `_medicine_id` INT)   BEGIN

SELECT m.medicine_id,m.price from medicines m WHERE m.medicine_id=_medicine_id;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `read_all_users` ()   BEGIN

SELECT u.user_id, u.image, concat(e.frist_name, ' ', e.last_name) as employe_name, u.username from users u JOIN employe e on u.employe_id=e.employe_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `read_amount` (IN `_pet_id` INT)   BEGIN


SELECT m.pet_id,m.price as price from medicalrecords m WHERE m.pet_id=_pet_id;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `read_employe_name` ()   BEGIN


SELECT e.employe_id,concat(e.frist_name, ' ', e.last_name) as employe_name from employe e WHERE e.employe_id NOT IN (SELECT u.employe_id from users u);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `read_employe_statement` (IN `_phone` INT)   BEGIN
if(_phone = '0000-00-00')THEN
SELECT e.frist_name,e.last_name,e.phone,e.city,e.state,b.address as branch,jt.position,jt.salary from employe e JOIN branch b on e.branch_id=b.branch_id JOIN job_title jt on e.title_id=jt.title_id;
ELSE
SELECT e.frist_name,e.last_name,e.phone,e.city,e.state,b.address as branch,jt.position,jt.salary from employe e JOIN branch b on e.branch_id=b.branch_id JOIN job_title jt on e.title_id=jt.title_id WHERE phone=_phone;
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `read_pet` (IN `_owner_id` VARCHAR(100))   BEGIN
SELECT p.pet_id,p.pet_name from medicalrecords mr JOIN owners o on mr.owner_id=o.owner_id JOIN pets p on mr.pet_id=p.pet_id WHERE o.owner_id=_owner_id;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `read_pets_statement` (IN `_pet_name` VARCHAR(100))   BEGIN
if(_pet_name = '')THEN
SELECT p.pet_id,o.owner_name,p.pet_name,p.gender,a.Name as animal_type,p.age,p.date FROM pets p JOIN owners o on p.owner_id=o.owner_id JOIN animaltype a on p.type_id=a.type_id;
ELSE
SELECT p.pet_id,o.owner_name,p.pet_name,p.gender,a.Name as animal_type,p.age,p.date FROM pets p JOIN owners o on p.owner_id=o.owner_id JOIN animaltype a on p.type_id=a.type_id WHERE p.pet_name=_pet_name;
END IF;
END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `read_acount_balance` (`_Account_id` INT) RETURNS INT(11)  BEGIN
SET @balance=0.00;
SELECT SUM(balance)INTO @balance FROM account WHERE Account_id
=_Account_id;
RETURN @balance;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `read_salary` () RETURNS DECIMAL(11,2)  BEGIN
SET @salary=0.00;
SELECT SUM(salary)INTO @salary FROM job_title;
RETURN @salary;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `Account_id` int(11) NOT NULL,
  `bank_name` varchar(50) NOT NULL,
  `holder_name` varchar(50) NOT NULL,
  `accoun_number` int(11) NOT NULL,
  `balance` decimal(12,0) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`Account_id`, `bank_name`, `holder_name`, `accoun_number`, `balance`, `date`) VALUES
(1, 'premier bank', 'farxaan', 675758, 4020, '2024-07-20 04:54:20'),
(2, 'Hormuud', 'saacid', 615566554, 20034, '2024-07-20 04:47:47'),
(3, 'Dahabshiil', 'nuur', 656765858, 8000, '2024-07-20 04:46:44');

-- --------------------------------------------------------

--
-- Table structure for table `animaltype`
--

CREATE TABLE `animaltype` (
  `type_id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `animaltype`
--

INSERT INTO `animaltype` (`type_id`, `Name`, `date`) VALUES
(1, 'Cat', '2024-07-20 04:18:31'),
(2, 'Dog', '2024-07-20 04:18:31'),
(3, 'Hamster', '2024-07-20 04:18:31'),
(4, 'Bird', '2024-07-20 04:18:31'),
(5, 'Rabbit', '2024-07-20 04:18:31');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `AppointmentID` int(11) NOT NULL,
  `pet_id` int(11) NOT NULL,
  `apointmentdate` datetime NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`AppointmentID`, `pet_id`, `apointmentdate`, `purpose`, `date`) VALUES
(1, 1, '2024-07-25 00:00:00', 'hubin', '2024-07-20 04:53:37');

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `bill_id` int(11) NOT NULL,
  `employe_id` int(11) NOT NULL,
  `Amount` decimal(12,0) NOT NULL,
  `user` varchar(40) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`bill_id`, `employe_id`, `Amount`, `user`, `date`) VALUES
(1, 1, 3000, 'samafale', '2024-07-20 04:54:58'),
(2, 2, 2000, 'samafale', '2024-07-20 04:55:06');

--
-- Triggers `bills`
--
DELIMITER $$
CREATE TRIGGER `update_charge_amount` AFTER INSERT ON `bills` FOR EACH ROW BEGIN

update charge set STATUS='paid' WHERE
employe_id=new.employe_id;


END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_id` int(11) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_id`, `address`, `city`, `state`, `date`) VALUES
(1, 'hodan', 'mugdisho', 'banadir', '2023-05-07 20:54:52'),
(3, 'hilwaa', 'mugdisho', 'banadir', '2023-05-08 22:13:50'),
(4, 'Km4', 'mugdisho', 'hiiran', '2023-06-17 09:03:38');

-- --------------------------------------------------------

--
-- Table structure for table `charge`
--

CREATE TABLE `charge` (
  `charge_id` int(11) NOT NULL,
  `employe_id` int(11) NOT NULL,
  `title_id` int(11) NOT NULL,
  `Amount` decimal(12,0) NOT NULL,
  `month_id` int(11) NOT NULL,
  `year` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `Account_id` int(11) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `status` varchar(40) NOT NULL DEFAULT 'pending',
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `charge`
--

INSERT INTO `charge` (`charge_id`, `employe_id`, `title_id`, `Amount`, `month_id`, `year`, `description`, `Account_id`, `user_id`, `status`, `date`) VALUES
(1, 2, 1, 2000, 1, '2024', 'mushaar', 1, 'samafale', 'paid', '2024-07-20 04:55:06'),
(2, 1, 2, 3000, 1, '2024', 'mushaar', 1, 'samafale', 'paid', '2024-07-20 04:54:58');

--
-- Triggers `charge`
--
DELIMITER $$
CREATE TRIGGER `update_balance` AFTER INSERT ON `charge` FOR EACH ROW BEGIN
UPDATE account SET balance= balance-new.Amount
WHERE Account_id=new.Account_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `employe`
--

CREATE TABLE `employe` (
  `employe_id` int(11) NOT NULL,
  `frist_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `title_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employe`
--

INSERT INTO `employe` (`employe_id`, `frist_name`, `last_name`, `phone`, `city`, `state`, `branch_id`, `title_id`, `date`) VALUES
(1, 'Moha', 'Ali', '617877876', 'mugdisho', 'banaadir', 4, 2, '2024-07-20 04:29:45'),
(2, 'Abdirahman', 'Ali', '615654543', 'mugdisho', 'banaadir', 1, 1, '2024-07-20 04:30:14');

-- --------------------------------------------------------

--
-- Table structure for table `job_title`
--

CREATE TABLE `job_title` (
  `title_id` int(11) NOT NULL,
  `position` varchar(50) NOT NULL,
  `salary` decimal(12,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_title`
--

INSERT INTO `job_title` (`title_id`, `position`, `salary`) VALUES
(1, 'waardiye', 2000),
(2, 'dr', 3000);

-- --------------------------------------------------------

--
-- Table structure for table `medicalrecords`
--

CREATE TABLE `medicalrecords` (
  `RecordID` int(11) NOT NULL,
  `pet_id` int(11) NOT NULL,
  `Notes` text NOT NULL,
  `medicine_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(12,0) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'pending',
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicalrecords`
--

INSERT INTO `medicalrecords` (`RecordID`, `pet_id`, `Notes`, `medicine_id`, `quantity`, `price`, `status`, `date`) VALUES
(1, 1, 'Feline Leukemia Virus', 3, 2, 20, 'paid', '2024-07-20 04:47:13'),
(2, 3, 'Parvovirus', 4, 2, 34, 'paid', '2024-07-20 04:47:47');

-- --------------------------------------------------------

--
-- Table structure for table `medicines`
--

CREATE TABLE `medicines` (
  `medicine_id` int(11) NOT NULL,
  `medicine_name` varchar(100) NOT NULL,
  `manufacturer` varchar(100) NOT NULL,
  `price` decimal(12,0) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicines`
--

INSERT INTO `medicines` (`medicine_id`, `medicine_name`, `manufacturer`, `price`, `date`) VALUES
(1, 'Pain Relief	', 'ZooCare	', 14, '2024-07-20 04:22:04'),
(2, 'Vaccine	', 'AnimalHealth	', 13, '2024-07-20 04:22:29'),
(3, 'Flea Control	', 'HealthyPets	', 10, '2024-07-20 04:22:51'),
(4, 'Dewormer', 'PetMeds', 17, '2024-07-20 04:23:19'),
(5, 'Probiotic', 'ZooCare	', 19, '2024-07-20 04:23:48'),
(6, 'Antibiotic	', 'HealthyPets	', 6, '2024-07-20 04:24:09'),
(7, 'Antifungal', 'PetMeds	', 12, '2024-07-20 04:24:35'),
(8, 'Anti-Inflammatory	', 'AnimalHealth	', 21, '2024-07-20 04:25:06');

-- --------------------------------------------------------

--
-- Table structure for table `month`
--

CREATE TABLE `month` (
  `month_id` int(11) NOT NULL,
  `month_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `month`
--

INSERT INTO `month` (`month_id`, `month_name`) VALUES
(1, 'January'),
(2, 'February'),
(3, 'March'),
(4, 'April'),
(5, 'May'),
(6, 'June'),
(7, 'July'),
(8, 'August'),
(9, 'September'),
(10, 'October'),
(11, 'November'),
(12, 'December');

-- --------------------------------------------------------

--
-- Table structure for table `owners`
--

CREATE TABLE `owners` (
  `owner_id` int(11) NOT NULL,
  `owner_name` varchar(100) NOT NULL,
  `phone` int(11) NOT NULL,
  `adress` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `owners`
--

INSERT INTO `owners` (`owner_id`, `owner_name`, `phone`, `adress`, `date`) VALUES
(2, 'saacid nuur', 614253454, 'hodan', '2024-07-20 04:36:10'),
(3, 'farxaan Abdi', 638373687, 'hilwaa', '2024-07-20 04:36:20'),
(4, 'shuuriye salaad', 615373832, 'hodan', '2024-07-20 04:36:39'),
(5, 'sharmaake ali', 613242536, 'hodan', '2024-07-20 04:39:17');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `pet_id` int(11) NOT NULL,
  `amount` decimal(12,0) NOT NULL,
  `Account_id` int(11) NOT NULL,
  `p_method_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `pet_id`, `amount`, `Account_id`, `p_method_id`, `date`) VALUES
(1, 1, 20, 1, 3, '2024-07-20 04:47:13'),
(2, 3, 34, 2, 1, '2024-07-20 04:47:47');

--
-- Triggers `payment`
--
DELIMITER $$
CREATE TRIGGER `update_account_balance` AFTER INSERT ON `payment` FOR EACH ROW BEGIN
UPDATE account SET balance= balance+new.amount
WHERE Account_id=new.Account_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_status` AFTER INSERT ON `payment` FOR EACH ROW BEGIN
UPDATE medicalrecords
        SET status = 'paid'
        WHERE pet_id=new.pet_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `payment_method`
--

CREATE TABLE `payment_method` (
  `p_method_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_method`
--

INSERT INTO `payment_method` (`p_method_id`, `name`) VALUES
(1, 'Evc'),
(2, 'EDahab'),
(3, 'Bank');

-- --------------------------------------------------------

--
-- Table structure for table `pets`
--

CREATE TABLE `pets` (
  `pet_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `pet_name` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `type_id` int(11) NOT NULL,
  `age` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pets`
--

INSERT INTO `pets` (`pet_id`, `owner_id`, `pet_name`, `gender`, `type_id`, `age`, `date`) VALUES
(1, 2, 'Buddy', 'female', 1, 3, '2024-07-20 04:37:39'),
(2, 3, 'Daisy', 'female', 1, 4, '2024-07-20 04:38:04'),
(3, 4, 'Lucy', 'male', 2, 6, '2024-07-20 04:38:33'),
(4, 5, 'Rocky', 'male', 2, 5, '2024-07-20 04:39:38');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` varchar(50) NOT NULL,
  `employe_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Active',
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `employe_id`, `username`, `password`, `image`, `status`, `date`) VALUES
('USR001', 1, 'moha', '202cb962ac59075b964b07152d234b70', 'USR001.png', 'Active', '2024-07-20 04:34:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`Account_id`);

--
-- Indexes for table `animaltype`
--
ALTER TABLE `animaltype`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`AppointmentID`);

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`bill_id`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `charge`
--
ALTER TABLE `charge`
  ADD PRIMARY KEY (`charge_id`),
  ADD UNIQUE KEY `employe_id` (`employe_id`,`month_id`,`year`),
  ADD UNIQUE KEY `employe_id_2` (`employe_id`,`month_id`,`year`);

--
-- Indexes for table `employe`
--
ALTER TABLE `employe`
  ADD PRIMARY KEY (`employe_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `title_id` (`title_id`);

--
-- Indexes for table `job_title`
--
ALTER TABLE `job_title`
  ADD PRIMARY KEY (`title_id`);

--
-- Indexes for table `medicalrecords`
--
ALTER TABLE `medicalrecords`
  ADD PRIMARY KEY (`RecordID`);

--
-- Indexes for table `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`medicine_id`);

--
-- Indexes for table `month`
--
ALTER TABLE `month`
  ADD PRIMARY KEY (`month_id`);

--
-- Indexes for table `owners`
--
ALTER TABLE `owners`
  ADD PRIMARY KEY (`owner_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `Account_id` (`Account_id`),
  ADD KEY `payment_method_id` (`p_method_id`),
  ADD KEY `payment_ibfk_2` (`pet_id`);

--
-- Indexes for table `payment_method`
--
ALTER TABLE `payment_method`
  ADD PRIMARY KEY (`p_method_id`);

--
-- Indexes for table `pets`
--
ALTER TABLE `pets`
  ADD PRIMARY KEY (`pet_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD KEY `employe_id` (`employe_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `Account_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `animaltype`
--
ALTER TABLE `animaltype`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `AppointmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bills`
--
ALTER TABLE `bills`
  MODIFY `bill_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `charge`
--
ALTER TABLE `charge`
  MODIFY `charge_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `employe`
--
ALTER TABLE `employe`
  MODIFY `employe_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `job_title`
--
ALTER TABLE `job_title`
  MODIFY `title_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `medicalrecords`
--
ALTER TABLE `medicalrecords`
  MODIFY `RecordID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `medicines`
--
ALTER TABLE `medicines`
  MODIFY `medicine_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `month`
--
ALTER TABLE `month`
  MODIFY `month_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `owners`
--
ALTER TABLE `owners`
  MODIFY `owner_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payment_method`
--
ALTER TABLE `payment_method`
  MODIFY `p_method_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `pets`
--
ALTER TABLE `pets`
  MODIFY `pet_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
