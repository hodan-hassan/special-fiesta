<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location:login.php');
    die();
}

?>





<?php


require 'include/header.php';

?>


<style>
    #show {
        width: 100px;
        height: 100px;
        border: solid 1px #744547;
        border-radius: 50%;
        object-fit: cover;
    }
</style>

<!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
        <!-- sidebar -->
        <?php
        require 'include/sidebar.php';

        ?>
        <!-- / sidebar -->

        <!-- Layout container -->
        <div class="layout-page">
            <!-- Navbar -->
            <?php
            include 'include/nav.php';
            ?>
            <!-- / Navbar -->

            <!-- Content wrapper -->
            <div class="content-wrapper">
                <!-- Content -->

                <div class="container mt-4">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="text-end">
                                    <button type="button" class="btn btn-success  m-2" data-bs-toggle="modal" data-bs-target="#usermodal">
                                        Add user
                                    </button>
                                </div>
                                <h5 class="card-header">Users Table</h5>
                                <div class="table-responsive text-nowrap" id="UserTable">
                                    <table class="table">
                                        <thead class="table-light">

                                        </thead>

                                        <tbody>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- / Content -->



                <div class="modal fade" id="usermodal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalCenterTitle">Users Modal</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <form id="userform">
                                        <input type="hidden" name="update_id" id="update_id">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <label for="">emname</label>
                                                    <select name="employe_nname" id="employe_nname" class="form-control form-control-lg employeeName">
                                                        <option value="0">select employee</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-sm-6 mt-4">
                                                <div class="form-group">
                                                    <label for="">username</label>
                                                    <input type="text" name="username" id="username" class="form-control form-control-lg" required>
                                                </div>

                                            </div>
                                            <div class="col-sm-6 mt-4">
                                                <div class="form-group">
                                                    <label for="">password</label>
                                                    <input type="password" name="password" id="password" class="form-control form-control-lg" required>
                                                </div>

                                            </div>

                                        </div>
                                        <div class="row mt-4">
                                            <div class="col-9">
                                                <div class="form-group">
                                                    <label>Image</label>
                                                    <input type="file" class="form-control" name="image" id="image" required>
                                                </div>
                                            </div>
                                            <div class="col-3"><img id="show"></div>
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                        Close
                                    </button>
                                    <button type="submit" class="btn btn-primary">Save changes</button>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>



                <!-- Footer -->

                <?php

                require 'include/footer.php';
                ?>
                <!-- / Footer -->

                <div class="content-backdrop fade"></div>
            </div>
            <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
    </div>

    <!-- Overlay -->
    <div class="layout-overlay layout-menu-toggle"></div>
</div>
<!-- / Layout wrapper -->

<?php
require 'include/script.php';
?>