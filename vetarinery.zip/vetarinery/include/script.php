<!-- Core JS -->
<!-- build:js assets/vendor/js/core.js -->
<script src="assets/vendor/libs/jquery/jquery.js"></script>
<script src="assets/vendor/libs/popper/popper.js"></script>
<script src="assets/vendor/js/bootstrap.js"></script>
<script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

<script src="assets/vendor/js/menu.js"></script>

<!-- endbuild -->



<!-- Vendors JS -->
<script src="assets/vendor/libs/apex-charts/apexcharts.js"></script>

<!-- Main JS -->
<script src="assets/js/main.js"></script>

<!-- Page JS -->
<script src="assets/js/dashboards-analytics.js"></script>

<!-- Place this tag in your head or just before your close body tag. -->
<script async defer src="https://buttons.github.io/buttons.js"></script>
<!-- <script src="sweetalert.min.js"></script> -->
<!-- <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script> -->

<script src="sweetalert.min.js"></script>




<!-- <script>
    $(document).ready(function() {
        $(function() {
            // Get the input fields with multiple classes
            var input = $(".validate");

            // Add a listener to the input fields
            input.on("keyup blur", function() {
                // Check if the input contains any non-letter characters
                if (!/^[a-zA-Z]+$/.test($(this).val())) {
                    // Clear the input field
                    $(this).val("");
                }
            });
        });
    });


    $(document).ready(function() {
        $(function() {
            // Get the input fields with multiple classes
            var input = $(".num");

            // Add a listener to the input fields
            input.on("keyup blur", function() {
                // Check if the input contains any non-letter characters
                if (!/^[0-9]+$/.test($(this).val())) {
                    // Clear the input field
                    $(this).val("");
                }
            });
        });
    });


    // $(document).ready(function() {
    //     $(function() {
    //         // Get the input field
    //         var input = $(".validate2");

    //         // Create a regular expression to match only letters and spaces
    //         var regex = /^[a-zA-Z\s]+$/;

    //         // Add a listener to the input field
    //         input.on("keyup blur", function() {
    //             // Check if the value of the input field matches the regular expression
    //             if (!regex.test(input.val())) {
    //                 // Set the input field's value to an empty string
    //                 // alert("looma ogolo number");
    //                 input.val("");




    //             }
    //         });
    //     });
    // });
</script> -->






<script src="javascript/user.js"></script>
<script src="javascript/employe.js"></script>
<script src="javascript/branch.js"></script>
<script src="javascript/job_title.js"></script>
<script src="javascript/customer.js"></script>
<script src="javascript/car_modals.js"></script>
<script src="javascript/suplier.js"></script>
<script src="javascript/car.js"></script>
<script src="javascript/account.js"></script>
<script src="javascript/login.js"></script>
<script src="javascript/selling.js"></script>
<script src="javascript/expense.js"></script>
<script src="javascript/p_method.js"></script>
<script src="javascript/payment.js"></script>
<script src="javascript/customer_repot.js"></script>
<script src="javascript/employe_repot.js"></script>
<script src="javascript/owners.js"></script>
<script src="javascript/pets.js"></script>
<script src="javascript/animal_type.js"></script>
<script src="javascript/dash.js"></script>
<script src="javascript/medicine.js"></script>
<script src="javascript/bills.js"></script>
<script src="javascript/medicalrecords.js"></script>
<script src="javascript/apointments.js"></script>
<script src="javascript/pets_repot.js"></script>
<script src="javascript/payment_repot.js"></script>
<script src="javascript/bill_repot.js"></script>
<script src="javascript/forgot.js"></script>
<script src="javascript/charge.js"></script>



</body>

</html>