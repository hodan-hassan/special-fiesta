<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">

        <div class="col-sm-3">
            <div class="card">
                <div class="card-body">
                    <div class="card-title d-flex align-items-start justify-content-between">
                        <div class="avatar flex-shrink-0">
                            <img src="assets/img/icons/unicons/cus.jpg" alt="Credit Card" class="rounded" />
                        </div>
                        <div class="dropdown">
                            <button class="btn p-0" type="button" id="cardOpt6" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt6">
                                <a class="dropdown-item" href="pets.php">View More</a>
                            </div>
                        </div>
                    </div>
                    <span>Total_pets</span>
                    <h3 class="card-title text-nowrap mb-1" id="total_pets"> <img src="assets/img/icons/unicons/cus.jpg" class="rounded" width="16" /> 9</h3>
                    <!-- +28.42%</small> -->
                </div>
            </div>
        </div>


        <div class="col-sm-3">
            <div class="card">
                <div class="card-body">
                    <div class="card-title d-flex align-items-start justify-content-between">
                        <div class="avatar flex-shrink-0">
                            <img src="assets/img/icons/unicons/users.png" alt="Credit Card" class="rounded" />
                        </div>
                        <div class="dropdown">
                            <button class="btn p-0" type="button" id="cardOpt6" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt6">
                                <a class="dropdown-item" href="employee.php">View More</a>
                            </div>
                        </div>
                    </div>
                    <span>Total Employee</span>
                    <h3 class="card-title text-nowrap mb-1" id="total_employe"><img src="assets/img/icons/unicons/users.png" class="rounded" width="16" /> 4</h3>
                </div>
            </div>
        </div>


        <div class="col-sm-3">
            <div class="card">
                <div class="card-body">
                    <div class="card-title d-flex align-items-start justify-content-between">
                        <div class="avatar flex-shrink-0">
                            <img src="assets/img/icons/unicons/us.png" alt="Credit Card" class="rounded" />
                        </div>
                        <div class="dropdown">
                            <button class="btn p-0" type="button" id="cardOpt6" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt6">
                                <a class="dropdown-item" href="account.php">View More</a>
                            </div>
                        </div>
                    </div>
                    <span>Total Income</span>
                    <h3 class="card-title text-nowrap mb-1 bi bi-currency-dollar" id="totalincome">$35.00</h3>
                </div>
            </div>
        </div>

        <div class="col-sm-3">
            <div class="card">
                <div class="card-body">
                    <div class="card-title d-flex align-items-start justify-content-between">
                        <div class="avatar flex-shrink-0">
                            <img src="assets/img/icons/unicons/ex.png" alt="Credit Card" class="rounded" />
                        </div>
                        <div class="dropdown">
                            <button class="btn p-0" type="button" id="cardOpt6" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt6">
                                <a class="dropdown-item" href="javascript:void(0);">View More</a>
                            </div>
                        </div>
                    </div>
                    <span>Total Expenses</span>
                    <h3 class="card-title text-nowrap mb-1" id="total_expenses">$4,679</h3>
                </div>
            </div>
        </div>
    </div>






</div>



</div>