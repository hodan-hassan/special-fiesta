<?php

$conn = new mysqli("localhost", "root", "", "veterinary");

if ($conn->connect_error) {
    echo $conn->error;
}
