<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location:login.php');
    die();
}

?>



<?php

include 'include/header.php';

?>
<!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
        <!-- sidebar -->
        <?php
        include 'include/sidebar.php';

        ?>
        <!-- / sidebar -->

        <!-- Layout container -->
        <div class="layout-page">
            <!-- Navbar -->
            <?php
            include 'include/nav.php';
            ?>
            <!-- / Navbar -->

            <!-- Content wrapper -->
            <div class="content-wrapper">
                <!-- Content -->

                <div class="container mt-4">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="text-end">
                                    <button type="button" class="btn btn-success  m-2" data-bs-toggle="modal" data-bs-target="#medicalrecordsmodal">
                                        Add medicalrecords
                                    </button>
                                </div>
                                <h5 class="card-header">medicalrecords Table</h5>
                                <div class="table-responsive text-nowrap" id="medicalrecordstable">
                                    <table class="table">
                                        <thead class="table-light">

                                        </thead>

                                        <tbody>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- / Content -->



                <div class="modal fade" id="medicalrecordsmodal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalCenterTitle">medicalrecords Modal</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">

                                <form id="medicalrecordsform">
                                    <input type="hidden" name="update_id" id="update_id">
                                    <div class="row">

                                        <div class="col-sm-12 mt-3">
                                            <div class="form-group">
                                                <select name="pet_id" id="pet_id" class="form-control pet_name" required>
                                                    <option value="0">select pet_name</option>
                                                </select>
                                            </div>

                                        </div>




                                        <div class="col-sm-12 mt-3">
                                            <div class="form-group">
                                                <input type="text" name="Notes" id="Notes" placeholder="Enter Notes" class="form-control validate" required>
                                            </div>

                                        </div>


                                        <div class="col-sm-12 mt-3">
                                            <div class="form-group">
                                                <select name="medicine_id" id="medicine_id" class="form-control medicine_name" required>
                                                    <option value="0">select medicine_name</option>
                                                </select>
                                            </div>

                                        </div>

                                        <div class="col-sm-12 mt-3">
                                            <div class="form-group">
                                                <input type="number" name="quantity" id="quantity" placeholder="Enter quantity Number" class="form-control num" required>
                                            </div>

                                        </div>

                                        <div class="col-sm-12 mt-3">
                                            <div class="form-group">
                                                <input type="text" name="price" id="price" placeholder="Enter price" class="form-control num" readonly required>
                                            </div>

                                        </div>







                                    </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                    Close
                                </button>
                                <button type="submit" class="btn btn-primary">Save changes</button>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>



                <!-- Footer -->

                <?php

                include 'include/footer.php';
                ?>
                <!-- / Footer -->

                <div class="content-backdrop fade"></div>
            </div>
            <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
    </div>

    <!-- Overlay -->
    <div class="layout-overlay layout-menu-toggle"></div>
</div>
<!-- / Layout wrapper -->

<?php
include 'include/script.php';
?>