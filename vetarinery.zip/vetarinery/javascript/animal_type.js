btnAction = "Insert";
load_AnimalType();

$("#AnimalType_form").on("submit", function (event) {

  event.preventDefault();


  let Name = $("#Name").val();
  let id = $("#update_id").val();

  let sendingData = {}

  if (btnAction == "Insert") {
    sendingData = {
      "Name": Name,
      "action": "register_AnimalType"
    }

  } else {
    sendingData = {
      "type_id": id,
      "Name": Name,
    }
  }



  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/animal_type.php",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        swal("Good job!", response, "success");
        btnAction = "Insert";
        load_AnimalType();
        $("#AnimalType_form")[0].reset();
        $("animal_type_modal").modal("hide");


      } else {
        swal("NOW!", response, "error");
      }

    },
    error: function (data) {
      swal("NOW!", response, "error");

    }

  })

})




function load_AnimalType() {
  $("#Animal_type_Table tbody").html('');
  $("#Animal_type_Table thead").html('');

  let sendingData = {
    "action": "read_all_AnimalType"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/animal_type.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';
      let th = '';

      if (status) {
        response.forEach(res => {
          th = "<tr>";
          for (let r in res) {
            th += `<th>${r}</th>`;
          }

        //   th += "<td>Action</td></tr>";




          tr += "<tr>";
          for (let r in res) {


            tr += `<td>${res[r]}</td>`;


          }
        //   tr += `<td> <a class="btn btn-info update_info"  update_id=${res['title_id']}><i class="mdi mdi-grease-pencil" style="color: #fff"></i></a>&nbsp;&nbsp <a class="btn btn-danger delete_info" delete_id=${res['title_id']}><i class="mdi mdi-close-box
        //   " style="color: #fff"></i></a> </td>`
          tr += "</tr>"

        })
        $("#Animal_type_Table thead").append(th);
        $("#Animal_type_Table tbody").append(tr);
      }

    },
    error: function (data) {

    }

  })
}