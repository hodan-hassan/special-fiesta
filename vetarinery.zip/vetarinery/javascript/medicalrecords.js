btnAction = "Insert";
fill_pets();
fill_medicine();
fill_pet();
loademedicalrecods();

function fill_pets() {

  let sendingData = {
    "action": "read_all_pets"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/pets.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';

      if (status) {
        response.forEach(res => {
          html += `<option value="${res['pet_id']}">${res['pet_name']}</option>`;

        })

        $("#pet_id").append(html);


      } else {
        displaymessage("error", response);
      }

    },
    error: function (data) {

    }

  })
}

function fill_medicine() {

  let sendingData = {
    "action": "read_all_medicine"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/medicine.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';

      if (status) {
        response.forEach(res => {
          html += `<option value="${res['medicine_id']}">${res['medicine_name']}</option>`;

        })

        $("#medicine_id").append(html);


      } else {
        displaymessage("error", response);
      }

    },
    error: function (data) {

    }

  })
}

$("#medicalrecordsform").on("submit", function (event) {

  event.preventDefault();

  let pet_name = $(".pet_name").val();
  let medicine_name = $(".medicine_name").val();
  

  if($(".pet_name").val()== 0){
      console.log("0 waaye");
  
      alert("select pet_name");

      return;

}  else if($(".medicine_name").val()== 0){
  alert("select medicine_name");

  return;
}



  let pet_id = $("#pet_id").val();
  let Notes = $("#Notes").val();
  let medicine_id = $("#medicine_id").val();
  let quantity = $("#quantity").val();
  let price = $("#price").val();
  let id = $("#update_id").val();

  let sendingData = {}

  if (btnAction == "Insert") {
    sendingData = {
      "pet_id": pet_id,
      "Notes": Notes,
      "medicine_id": medicine_id,
      "quantity": quantity,
      "price": price,
      "action": "register_medicalrecords"
    }

  } else {
    sendingData = {
      "sell_id": id,
      "customer_id": customer_id,
      "car_id": car_id,
      "quantity": quantity,
      "price": price,
      "balance": balance,
      "action": "update_sell"
    }
  }



  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/medicalrecords.php",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        swal("Good job!", response, "success");
        btnAction = "Insert";
        loademedicalrecods();
        $("#medicalrecordsform")[0].reset();
        $("#medicalrecordsmodal").modal("hide");


      } else {
        swal("NOW!", response, "error");

      
      }

    },
    error: function (data) {
        swal("NOW!", response, "error");

    }

  })

})

$("#medicalrecordsform").on("change", "select.medicine_name", function () {
    let medicine_name = $(this).val();
    console.log("name", medicine_name);
    fill_price2(medicine_name);
    $("#quantity").val()==0;
  
  })



  $("#medicalrecordsform").on("change", "select.owner_namee", function () {
    let owner_namee = $(this).val();
    console.log("name", owner_namee);
    fill_pet(owner_namee);
  
  })
  



  function fill_pet(owner_id) {
    let sendingData = {
      "action": "read_pet",
      "owner_id": owner_id
  
    }
  
    $.ajax({
      method: "POST",
      dataType: "JSON",
      url: "Api/medicalrecods.php",
      data: sendingData,
  
      success: function (data) {
        let status = data.status;
        let response = data.data;
        console.log("name", response)
        let html = '';
        let tr = '';
  
        if (status) {
  
          response.forEach(res => {
            $("#pet_id").val(res['pet_name']);
  
          })
  
  
  
        } else {
          displaymessage("error", response);
        }
  
      },
      error: function (data) {
  
      }
  
    })
  }
  
  
  $("#quantity").on("change", function () {
    let quantity = $(this).val();
   let medicine_id = $("#medicine_id").val();
    fill_price(medicine_id, quantity);
    console.log("quantity",quantity);
    console.log("medicine_id",medicine_id);

})


$("#medicine_id").on("change", function(){
  if($("#medicine_id").val()== 0){
    console.log("0 waaye");
    $("#quantity").val("");
    $("#price").val("");

  }else{
    console.log(quantity);
  }
})

  
function fill_price(medicine_id, quantity) {
    
    let sendingData = {
      "action": "read_all_medicine_price",
      "medicine_id": medicine_id

      
  
    }

  
    $.ajax({
      method: "POST",
      dataType: "JSON",
      url: "Api/medicalrecords.php",
      data: sendingData,
  
      success: function (data) {
        let status = data.status;
        let response = data.data;
        console.log("name", response)
        let html = '';
        let tr = '';
  
        if (status) {
  
          response.forEach(res => {
            $("#price").val(res['price']*quantity);
  
          })
  
  
  
        } else {
          displaymessage("error", response);
        }
  
      },
      error: function (data) {
  
      }
  
    })
  }


function fill_price2(medicine_id) {
    
  let sendingData = {
    "action": "read_all_medicine_price",
    "medicine_id": medicine_id

    

  }


  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/medicalrecords.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      console.log("name", response)
      let html = '';
      let tr = '';

      if (status) {

        response.forEach(res => {
          $("#price").val(res['price']);

        })



      } else {
        displaymessage("error", response);
      }

    },
    error: function (data) {

    }

  })
}


function loademedicalrecods() {
  $("#medicalrecordstable tbody").html('');
  $("#medicalrecordstable thead").html('');

  let sendingData = {
    "action": "read_all_medicalrecords"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/medicalrecords.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';
      let th = '';

      if (status) {
        response.forEach(res => {
          th = "<tr>";
          for (let r in res) {
            th += `<th>${r}</th>`;
          }

        //   th += "<td>Action</td></tr>";




          tr += "<tr>";
          for(let r in res){

           
            if(r=="price"){
              tr += `<td>$${res[r]}</td>`;

            }else if(r=="balance"){
              tr += `<td>$${res[r]}</td>`;


            }

           else if(r == "status"){
              if(res[r] == "paid"){
                  tr += `<td><span class="btn btn-success btn-sm">${res[r]}</span></td>`;
              }else{
                  tr += `<td><span class="btn btn-danger btn-sm">${res[r]}</span></td>`;
              }
          }
            
            else{
              tr += `<td>${res[r]}</td>`;
            }

      }
    //     tr += `<td <div class="dropdown">
    //     <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
    //         <i class="bx bx-dots-vertical-rounded"></i>
    //     </button>
    //     <div class="dropdown-menu">
    //     </div>
    // </div></td>`
    //     tr += "</tr>"

        })
        $("#medicalrecordstable thead").append(th);
        $("#medicalrecordstable tbody").append(tr);
      }

    },
    error: function (data) {

    }

  })
}



