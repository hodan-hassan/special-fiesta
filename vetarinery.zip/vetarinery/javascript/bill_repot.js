
$("#printtstatement").on("click", function(){
    printStatement();
    
})

function printStatement(){
    let printarea= document.querySelector("#prinT_Area");
  
    
    let newwindow= window.open("");
    newwindow.document.write(`<html><head><title></title>`);
    newwindow.document.write(`<style media="print">
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap');
    body{
        font-family: 'Poppins', sans-serif;
    }

    table{
      width:60%;
  }

    th{
        background-color : #40E0D0 !important;
        color: white !important;
       
    }
      
    th , td{
        padding:10px !important;
        text-align: left !important;

    }

    th , td{
        
        border-bottom : 1px solid #ddd !important;
    }
    
    
    </style>`);
    newwindow.document.write(`</head><body>`);
    newwindow.document.write(printarea.innerHTML);
    newwindow.document.write(`</body></html>`);
    newwindow.print();
    newwindow.close();

    
}


// $("#exporttstatement").on("click", function(){
//     let file= new Blob([$('#prinT_Area').html()], {type:"application/vnd.ms-excel"});
//     let url= URL.createObjectURL(file);
//     let a= $("<a />", {
//         href: url,
//         download: "print_statement.xls"}).appendTo("body").get(0).click();
//         e.preventDefault();

// });


$("#exporttstatement").on("click", function (e) {
  e.preventDefault();
  
  // Get the HTML content of the table
  let tableHTML = $('#prinT_Area').html();
  
  // Add Excel-specific HTML structure
  let excelHTML = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
          <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
          <!--[if gte mso 9]>
          <xml>
              <x:ExcelWorkbook>
                  <x:ExcelWorksheets>
                      <x:ExcelWorksheet>
                          <x:Name>Sheet1</x:Name>
                          <x:WorksheetOptions>
                              <x:DisplayGridlines/>
                          </x:WorksheetOptions>
                      </x:ExcelWorksheet>
                  </x:ExcelWorksheets>
              </x:ExcelWorkbook>
          </xml>
          <![endif]-->
      </head>
      <body>
          <table>${tableHTML}</table>
      </body>
      </html>`;

  // Encode the HTML content as base64
  let base64ExcelHTML = btoa(unescape(encodeURIComponent(excelHTML)));
  
  // Create a Data URI for the file
  let dataUri = 'data:application/vnd.ms-excel;base64,' + base64ExcelHTML;
  
  // Create a download link and trigger a click event to download the file
  let a = $("<a />", {
      href: dataUri,
      download: "print_statement.xls"
  }).appendTo("body").get(0).click();
});




$("#bills_repoform").on("submit", function(event){
    
    event.preventDefault();
    $("#bills_repotable tr").html("");


    let month= $("#month").val();
    
 
  
    let sendingData = {
       
         "month" : month,
         
        "action": "read_bills_statement",
       
    }
    


  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/bils.php",
    data : sendingData,
    success: function(data){
        let status= data.status;
        let response= data.data;
   
        let tr= '';
        let th= '';

        if(status){
            response.forEach(res=>{

                th = "<tr>";
                for(let r in res){
                th += `<th>${r}</th>`;
               }

               th += "</tr>";


                tr += "<tr>";
                for(let r in res){
                  if(r=="salary"){
                    tr += `<td>$${res[r]}</td>`;
                  }else{
                    tr += `<td>${res[r]}</td>`;
      
                  }

                }

                tr+= "</tr>"
              
            })

            $("#bills_repotable thead").append(th);
            $("#bills_repotable tbody").append(tr);
        }

    },
    error: function(data){

    }

  })

})




function loadData(){
  $("#employeetable tbody").html('');
 
  let sendingData ={
      "action": "get_employe_info"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/employe.php",
    data : sendingData,

      success : function(data){
          let status= data.status;
          let response= data.data;
          let html='';
          let tr= '';

          if(status){
            response.forEach(res=>{

                th = "<tr>";
                for(let r in res){
                th += `<th>${r}</th>`;
               }

               th += "</tr>";


                tr += "<tr>";
                for(let r in res){

                  if(r=="salary"){
                    tr += `<td>$${res[r]}</td>`;
                  }else{
                    tr += `<td>${res[r]}</td>`;
      
                  }

                }

                tr+= "</tr>"
              
            })

            $("#employeetable thead").append(th);
            $("#employeetable tbody").append(tr);
        }

    },
    error: function(data){

    }

  })
}



