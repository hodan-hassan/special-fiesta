$("#pets_name").attr("disabled", true);

$("#type").on("change", function(){
    if($("#type").val()== 0){
    $("#pets_name").attr("disabled", true);

    }else{
        $("#pets_name").attr("disabled", false);
    }
})

$("#printt_statement").on("click", function(){
  let printarea= document.querySelector("#printt_Area");
  
    
  let newwindow= window.open("");
  newwindow.document.write(`<html><head><title></title>`);
  newwindow.document.write(`<style media="print">
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap');
  body{
      font-family: 'Poppins', sans-serif;
  }

  table{
    width:60%;
}

  th{
      background-color : #40E0D0 !important;
      color: white !important;
     
  }
    
  th , td{
      padding:10px !important;
      text-align: left !important;

  }

  th , td{
      
      border-bottom : 1px solid #ddd !important;
  }
  
  
  </style>`);
  newwindow.document.write(`</head><body>`);
  newwindow.document.write(printarea.innerHTML);
  newwindow.document.write(`</body></html>`);
  newwindow.print();
  newwindow.close();
})




$("#exportt_statement").on("click", function(){
    let file= new Blob([$('#prinT_Area').html()], {type:"application/vnd.ms-excel"});
    let url= URL.createObjectURL(file);
    let a= $("<a />", {
        href: url,
        download: "print_statement.xls"}).appendTo("body").get(0).click();
        e.preventDefault();

});



$("#petsform").on("submit", function(event){
    
    event.preventDefault();
    $("#petstable tr").html("");


    let pets_name= $("#pets_name").val();
    
 
  
    let sendingData = {
       
         "pets_name" : pets_name,
         
        "action": "read_pets_statement",
       
    }
    


  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/pets.php",
    data : sendingData,
    success: function(data){
        let status= data.status;
        let response= data.data;
   
        let tr= '';
        let th= '';

        if(status){
            response.forEach(res=>{

                th = "<tr>";
                for(let r in res){
                th += `<th>${r}</th>`;
               }

               th += "</tr>";


                tr += "<tr>";
                for(let r in res){
                  if(r=="salary"){
                    tr += `<td>$${res[r]}</td>`;
                  }else{
                    tr += `<td>${res[r]}</td>`;
      
                  }

                }

                tr+= "</tr>"
              
            })

            $("#petstable thead").append(th);
            $("#petstable tbody").append(tr);
        }

    },
    error: function(data){

    }

  })

})




function loadData(){
  $("#petstable tbody").html('');
 
  let sendingData ={
      "action": "get_pets_info"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/pets.php",
    data : sendingData,

      success : function(data){
          let status= data.status;
          let response= data.data;
          let html='';
          let tr= '';

          if(status){
            response.forEach(res=>{

                th = "<tr>";
                for(let r in res){
                th += `<th>${r}</th>`;
               }

               th += "</tr>";


                tr += "<tr>";
                for(let r in res){

                  if(r=="salary"){
                    tr += `<td>$${res[r]}</td>`;
                  }else{
                    tr += `<td>${res[r]}</td>`;
      
                  }

                }

                tr+= "</tr>"
              
            })

            $("#petstable thead").append(th);
            $("#petstable tbody").append(tr);
        }

    },
    error: function(data){

    }

  })
}



