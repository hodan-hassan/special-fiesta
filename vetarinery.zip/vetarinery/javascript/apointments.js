loadapointments();

btnAction = "Insert";

fill_paid_pets();
function fill_paid_pets() {

  let sendingData = {
    "action": "read_paid_pets"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/apointments.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';

      if (status) {
        response.forEach(res => {
        
          html += `<option value="${res['pet_id']}">${res['pet_name']}</option>`;


        })

        $("#pets_id").append(html);


      } else {
        displaymssage("error", response);
      }

    },
    error: function (data) {

    }

  })
}

$("#apointmentform").on("submit", function (event) {

  event.preventDefault();


  let pets_id = $("#pets_id").val();
  let apointmentdate = $("#apointmentdate").val();
  let purpose = $("#purpose").val();
  let id = $("#update_id").val();

  let sendingData = {}

  if (btnAction == "Insert") {
    sendingData = {
      "pets_id": pets_id,
      "apointmentdate": apointmentdate,
      "purpose": purpose,
      "action": "register_apointments"
    }

  } else {
    sendingData = {
      "AppointmentID": id,
      "pets_id": pets_id,
      "apointmentdate": apointmentdate,
      "purpose": purpose,
      "action": "update_apointment"
    }
  }



  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/apointments.php",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        swal("Good job!", response, "success");
        btnAction = "Insert";
        loadapointments();
        $("#apointmentform")[0].reset();
        $("#apointmentmodal").modal("hide");
        






      } else {
        swal("NOW!", response, "error");

  
      }

    },
    error: function (data) {
      swal("NOW!", response, "error");


    }

  })

})


function loadapointments() {
  $("#apointmenttable tbody").html('');
  $("#apointmenttable thead").html('');

  let sendingData = {
    "action": "read_all_apointments"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/apointments.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';
      let th = '';

      if (status) {
        response.forEach(res => {
          th = "<tr>";
          for (let r in res) {
            th += `<th>${r}</th>`;
          }

          th += "<td>Action</td></tr>";




          tr += "<tr>";
          for (let r in res) {


            tr += `<td>${res[r]}</td>`;


          }

          tr += `<td <div class="dropdown">
          <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
              <i class="bx bx-dots-vertical-rounded"></i>
          </button>
          <div class="dropdown-menu">
              <a class="dropdown-item  update_info" href="javascript:void(0);" update_id=${res['AppointmentID']}><i class="bx bx-edit-alt me-1"></i> Edit</a>
          </div>
      </div></td>`
          tr += "</tr>"

          // tr += `<td> <a class="btn btn-info update_info"  update_id=${res['Account_id']}><i class="mdi mdi-grease-pencil" style="color: #fff"></i></a>&nbsp;&nbsp <a class="btn btn-danger delete_info" delete_id=${res['Account_id']}><i class="mdi mdi-close-box
          // " style="color: #fff"></i></a> </td>`
          // tr += "</tr>"

        })
        $("#apointmenttable thead").append(th);
        $("#apointmenttable tbody").append(tr);
      }


    },
    error: function (data) {

    }

  })
}

function get_apointment_info(AppointmentID) {

  let sendingData = {
    "action": "get_apointment_info",
    "AppointmentID": AppointmentID
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/apointments.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;


      if (status) {

        btnAction = "update";

        $("#update_id").val(response['AppointmentID']);
        $("#pets_id").val(response['pet_id']);
        $("#apointmentdate").val(response['apointmentdate']);
        $("#purpose").val(response['purpose']);
        $("#apointmentmodal").modal('show');




      } else {
        dispalaymessage("error", response);
      }

    },
    error: function (data) {

    }

  })
}



$("#apointmenttable").on('click', "a.update_info", function () {
  let id = $(this).attr("update_id");
  get_apointment_info(id)
})


