
$("#forgotForm").on("submit", function (e) {

    e.preventDefault();
    let yourusername = $("#yourusername").val();
    let yourPassword = $("#yourPassword").val();
  
  
    let sendingData = {
      "action": "forgot",
      "yourusername": yourusername,
      "yourPassword": yourPassword
    }
  
    $.ajax({
      method: "POST",
      dataType: "JSON",
      url: "Api/forgot.php",
      data: sendingData,
  
      success: function (data) {
        let status = data.status;
        let response = data.data;
  
  
        if (status) {
            dispalaymessage("success", response);
            btnAction = "Insert";
            $("#forgotForm")[0].reset();
  
  
        //  window.location.href = "index.php";
  
        } else {
            dispalaymessage("error", response);

        //  swal("NOW!", response, "error");
        }
  
      },
      error: function (data) {
  
      }
  
    })
  
  })



function dispalaymessage(type, message){
    let success =   document.querySelector(".alert-success");
    let error =   document.querySelector(".alert-danger");
    if(type== "success"){
      error.classList= "alert alert-danger d-none";
       success.classList= "alert alert-success";
       success.innerHTML= message;
  
       setTimeout(function(){
         $("#paymentmodal").modal("hide");
        success.classList= "alert alert-success d-none";
        $("#paymentform")[0].reset();
  
       },2000);
  
  
    }else{
      error.classList= "alert alert-danger";
      error.innerHTML= message;
    }
  }
  
  
  
  
  
  
  
  