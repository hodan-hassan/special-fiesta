btnAction = "Insert";
fillowners();
fill_type();
loadpets();

function fillowners() {

  let sendingData = {
    "action": "read_all_owner"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/owners.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';

      if (status) {
        response.forEach(res => {
          html += `<option value="${res['owner_id']}">${res['owner_name']}</option>`;

        })

        $("#owner_id").append(html);


      } else {
        displaymessage("error", response);
      }

    },
    error: function (data) {

    }

  })
}

function fill_type() {

  let sendingData = {
    "action": "read_all_AnimalType"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/animal_type.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';

      if (status) {
        response.forEach(res => {
          html += `<option value="${res['type_id']}">${res['Name']}</option>`;

        })

        $("#type_id").append(html);


      } else {
        displaymessage("error", response);
      }

    },
    error: function (data) {

    }

  })
}

$("#pets_form").on("submit", function (event) {

  event.preventDefault();

  let owner = $(".owner_id").val();
  let pet = $(".pet_name").val();
  

  if($(".owner_id").val()== 0){
      console.log("0 waaye");
  
      alert("select owners");

      return;

}  else if($(".pet_name").val()== 0){
  alert("select pet_name");

  return;
}




  let owner_id = $("#owner_id").val();
  let pet_name = $("#pet_name").val();
  let gender = $("#gender").val();
  let type_id = $("#type_id").val();
  let age = $("#age").val();
  let id = $("#update_id").val();

  let sendingData = {}

  if (btnAction == "Insert") {
    sendingData = {
      "owner_id": owner_id,
      "pet_name": pet_name,
      "gender": gender,
      "type_id": type_id,
      "age": age,
      "action": "register_pets"
    }

  } else {
    sendingData = {
      "pet_id": id,
      "owner_id": owner_id,
      "pet_name": pet_name,
      "gender": gender,
      "type_id": type_id,
      "age": age,
      "action": "update_pets"
    }
  }



  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/pets.php",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        swal("Good job!", response, "success");
        btnAction = "Insert";
        $("#pets_form")[0].reset();
        $("#pets_modal").modal("hide");
        loadpets();



      } else {
        swal("NOW!", response, "error");
      }

    },
    error: function (data) {
      swal("NOW!", response, "error");

    }

  })

})


function loadpets() {
  $("#pets_table tbody").html('');
  $("#pets_table thead").html('');

  let sendingData = {
    "action": "read_all_pets"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/pets.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';
      let th = '';

      if (status) {
        response.forEach(res => {
          th = "<tr>";
          for (let r in res) {
            th += `<th>${r}</th>`;
          }

          th += "<td>Action</td></tr>";




          tr += "<tr>";
          for (let r in res) {

            if(r=="salary"){
              tr += `<td>$${res[r]}</td>`;
            }else{
              tr += `<td>${res[r]}</td>`;

            }



          }

          tr += `<td <div class="dropdown">
          <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
              <i class="bx bx-dots-vertical-rounded"></i>
          </button>
          <div class="dropdown-menu">
              <a class="dropdown-item  update_info" href="javascript:void(0);" update_id=${res['pet_id']}><i class="bx bx-edit-alt me-1"></i> Edit</a>
              <a class="dropdown-item delete_info" href="javascript:void(0);" delete_id=${res['pet_id']}><i class="bx bx-trash me-1"></i> Delete</a>
          </div>
      </div></td>`
          tr += "</tr>"

         

        })
        $("#pets_table thead").append(th);
        $("#pets_table tbody").append(tr);
      }

    },
    error: function (data) {

    }

  })
}

function get_pets_info(pet_id) {

  let sendingData = {
    "action": "get_pets_info",
    "pet_id": pet_id
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/pets.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;


      if (status) {

        btnAction = "update";

        $("#update_id").val(response['pet_id']);
        $("#owner_id").val(response['owner_id']);
        $("#pet_name").val(response['pet_name']);
        $("#gender").val(response['gender']);
        $("#type_id").val(response['type_id']);
        $("#age").val(response['age']);
        $("#pets_modal").modal('show');




      } else {
        employemessage("error", response);
      }

    },
    error: function (data) {

    }

  })
}


function Delete_pets(pet_id) {

  let sendingData = {
    "action": "Delete_pets",
    "pet_id": pet_id
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/pets.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;


      if (status) {

        swal("Good job!", response, "success");
        loadpets();


      } else {
        swal("NOW!", response, "error");

      
      }

    },
    error: function (data) {

    }

  })
}



$("#pets_table").on('click', "a.update_info", function () {
  let id = $(this).attr("update_id");
  get_pets_info(id)
})


$("#pets_table").on('click', "a.delete_info", function () {
  let id = $(this).attr("delete_id");
  if (confirm("Are you sure To Delete")) {
    Delete_pets(id)

  }

})