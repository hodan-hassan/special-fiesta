fill_petss();
fillaccoun();
load_payment();
fill_p_method();
fill_amount();
function fill_petss() {

  let sendingData = {
    "action": "read_pets"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/payment.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';

      if (status) {
        response.forEach(res => {
          html += `<option value="${res['pet_id']}">${res['pet_name']}</option>`;

        })

        $("#pet_iddd").append(html);


      } else {
        displaymessage("error", response);
      }

    },
    error: function (data) {

    }

  })
}

$("#pet_iddd").on("change", function(){
  if($("#pet_iddd").val()== 0){
    console.log("0 waaye");
    $("#amount").val("");

  }else{
    console.log(amount);
  }
})

function fillaccoun() {

  let sendingData = {
    "action": "read_all_account"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/account.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';

      if (status) {
        response.forEach(res => {
          html += `<option value="${res['Account_id']}">${res['bank_name']}</option>`;

        })

        $("#Accountt_id").append(html);


      } else {
        displaymessage("error", response);
      }

    },
    error: function (data) {

    }

  })
}

function fill_p_method() {

  let sendingData = {
    "action": "read_all_p_method"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/pe_method.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';

      if (status) {
        response.forEach(res => {
          html += `<option value="${res['p_method_id']}">${res['name']}</option>`;

        })

        $("#p_method_id").append(html);


      } else {
        displaymessage("error", response);
      }

    },
    error: function (data) {

    }

  })
}

btnAction = "Insert";

$("#paymentform").on("submit", function (event) {

  event.preventDefault();

 


//  $(".amount_paid").on("keyup", function(){
//   let Amount_paid = $(".amount_paid").val();
//   let Total_amount = $(".amount").val();
  
//   if(Amount_paid > Total_amount){
//     console.log(Amount_paid);


//     alert("Amount paid is greater than Total Amount that is not immpossible");

//     return;
// }
//  })

let bank = $(".bank").val();
let method = $(".method").val();
let pet_name = $(".pet_name").val();


if($(".pet_name").val()== 0){
    console.log("0 waaye");

    alert("select pet_name");

    return;

}  else if($(".bank").val()== 0){
  alert("select bank");

return;

}  else if($(".method").val()== 0){
  alert("select method");
  
  return;
}


  let pet_iddd = $("#pet_iddd").val();
  let amount = $("#amount").val();
  let Accountt_id = $("#Accountt_id").val();
  let p_method_id = $("#p_method_id").val();
  let id = $("#update_id").val();

  let sendingData = {}

  if (btnAction == "Insert") {
    sendingData = {
      "pet_iddd": pet_iddd,
      "amount": amount,
      "Accountt_id": Accountt_id,
      "p_method_id": p_method_id,
      "action": "register_payment"
    }

  } else {
    sendingData = {
      "payment_id": id,
      "customer_idd": customer_idd,
      "amount": amount,
      "amount_paid": amount_paid,
      "balance": balance,
      "Accountt_id": Accountt_id,
      "p_method_id": p_method_id,
      "action": "update_payment"
    }
  }



  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/payment.php",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        swal("Good job!", response, "success");
        btnAction = "Insert";
        load_payment();
        $("#paymentform")[0].reset();
        $("#payment_modal").modal("hide");





      } else {
        swal("NOW!", response, "error");

      
      }

    },
    error: function (data) {
      swal("NOW!", response, "error");


    }

  })

})


$("#paymentform").on("change", "select.pet_name", function () {
  let pet_name = $(this).val();
  console.log("name", pet_name);
  fill_amount(pet_name);

})



// $(function(){
//   $('#dropdown').on('change',function(){

//    var id = $(this).val();
//    $.post('get_payment_fee.php',{id:$(this).val()},function(res){
//    var res1 = res.split(",");

//    $("#amount").val($.trim(res1[0]));
   
          
//    });

//    });
// });




function fill_amount(pet_id) {
  let sendingData = {
    "action": "read_amount",
    "pet_id": pet_id

  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/payment.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      console.log("name", response)
      let html = '';
      let tr = '';

      if (status) {

        response.forEach(res => {
          $("#amount").val(res['price']);

        })



      } else {
        displaymessage("error", response);
      }

    },
    error: function (data) {

    }

  })
}




function load_payment() {
  $("#paymentTable tbody").html('');
  $("#paymentTable thead").html('');

  let sendingData = {
    "action": "read_all_payment"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/payment.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';
      let th = '';


      if (status) {
        response.forEach(res => {
          tr += "<tr>";
          th = "<tr>";
          for (let r in res) {
            th += `<th>${r}</th>`;

            if(r=="Total_amount"){
              tr += `<td>$${res[r]}</td>`;

            }else if(r=="amount_paid"){
              tr += `<td>$${res[r]}</td>`;


            }

            else if (r == "balance") {
              if (res[r] == 0) {
                tr += `<td><span class="btn btn-success btn-sm">✔</span></td>`;
              } else {
                tr += `<td><span class="btn btn-danger btn-sm">$ ${res[r]}</span></td>`;
              }
            } else {
              tr += `<td>${res[r]}</td>`;
            }

          }

          tr += "</tr>"

        })

        $("#paymentTable thead").append(th);
        $("#paymentTable tbody").append(tr);
      }



    },
    error: function (data) {

    }

  })
}


