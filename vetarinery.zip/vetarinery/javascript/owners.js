loadowners();

btnAction = "Insert";


$("#ownersForm").on("submit", function (event) {

  event.preventDefault();


  let owner_name = $("#owner_name").val();
  let phone = $("#phone").val();
  let adress = $("#adress").val();
  let id = $("#update_id").val();

  let sendingData = {}

  if (btnAction == "Insert") {
    sendingData = {
      "owner_name": owner_name,
      "phone": phone,
      "adress": adress,
      "action": "register_owner"
    }

  } else {
    sendingData = {
      "owner_id": id,
      "owner_name": owner_name,
      "phone": phone,
      "adress": adress,
      "action": "update_owner"
    }
  }



  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/owners.php",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        swal("Good job!", response, "success");
        btnAction = "Insert";
        loadowners();
        $("#ownersForm")[0].reset();
        $("#owners_modal").modal("hide");
        






      } else {
        swal("NOW!", response, "error");

  
      }

    },
    error: function (data) {
      swal("NOW!", response, "error");


    }

  })

})


function loadowners() {
  $("#ownersTable tbody").html('');
  $("#ownersTable thead").html('');

  let sendingData = {
    "action": "read_all_owner"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/owners.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';
      let th = '';

      if (status) {
        response.forEach(res => {
          th = "<tr>";
          for (let r in res) {
            th += `<th>${r}</th>`;
          }

          th += "<td>Action</td></tr>";




          tr += "<tr>";
          for (let r in res) {


            tr += `<td>${res[r]}</td>`;


          }

          tr += `<td <div class="dropdown">
          <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
              <i class="bx bx-dots-vertical-rounded"></i>
          </button>
          <div class="dropdown-menu">
              <a class="dropdown-item  update_info" href="javascript:void(0);" update_id=${res['owner_id']}><i class="bx bx-edit-alt me-1"></i> Edit</a>
              <a class="dropdown-item delete_info" href="javascript:void(0);" delete_id=${res['owner_id']}><i class="bx bx-trash me-1"></i> Delete</a>
          </div>
      </div></td>`
          tr += "</tr>"

          // tr += `<td> <a class="btn btn-info update_info"  update_id=${res['Account_id']}><i class="mdi mdi-grease-pencil" style="color: #fff"></i></a>&nbsp;&nbsp <a class="btn btn-danger delete_info" delete_id=${res['Account_id']}><i class="mdi mdi-close-box
          // " style="color: #fff"></i></a> </td>`
          // tr += "</tr>"

        })
        $("#ownersTable thead").append(th);
        $("#ownersTable tbody").append(tr);
      }


    },
    error: function (data) {

    }

  })
}

function get_owner_info(owner_id) {

  let sendingData = {
    "action": "get_owner_info",
    "owner_id": owner_id
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/owners.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;


      if (status) {

        btnAction = "update";

        $("#update_id").val(response['owner_id']);
        $("#owner_name").val(response['owner_name']);
        $("#phone").val(response['phone']);
        $("#adress").val(response['adress']);
        $("#owners_modal").modal('show');




      } else {
        dispalaymessage("error", response);
      }

    },
    error: function (data) {

    }

  })
}

function Delete_owners(owner_id) {

  let sendingData = {
    "action": "Delete_owners",
    "owner_id": owner_id
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/owners.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;


      if (status) {

        swal("Good job!", response, "success");
        loadowners();


      } else {
        swal("NOW!", response, "error");

      
      }

    },
    error: function (data) {

    }

  })
}

$("#ownersTable").on('click', "a.update_info", function () {
  let id = $(this).attr("update_id");
  get_owner_info(id)
})


$("#ownersTable").on('click', "a.delete_info", function () {
  let id = $(this).attr("delete_id");
  if (confirm("Are you sure To Delete")) {
    Delete_owners(id)

  }

})