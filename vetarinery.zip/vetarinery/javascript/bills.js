loadbills();
// fill_salary();
fill_employe();
function fill_employe() {

  let sendingData = {
    "action": "read_all_employeeee"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/bils.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';

      if (status) {
        response.forEach(res => {
        
          html += `<option value="${res['employe_id']}">${res['employe_name']}</option>`;


        })

        $("#employee").append(html);


      } else {
        displaymssage("error", response);
      }

    },
    error: function (data) {

    }

  })
}

btnAction = "Insert";

$("#billform").on("submit", function (event) {

  event.preventDefault();



  let employeee = $(".employee").val();
  

  if($(".employee").val()== 0){
      console.log("0 waaye");
  
      alert("select Employee");

      return;
}


  let employee = $("#employee").val();
  let amount = $("#amount").val();
  let user = $("#user").val();
  let id = $("#update_id").val();

  let sendingData = {}

  if (btnAction == "Insert") {
    sendingData = {
      "employee": employee,
      "amount": amount,
      "user": user,
      "action": "register_bills"
    }

  
  }



  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/bils.php",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        swal("Good job!", response, "success");
        btnAction = "Insert";
        loadbills();
        $("#billform")[0].reset();
        $("#bilsmodal").modal("hide");







      } else {
        swal("NOW!", response, "error");

      
      }

    },
    error: function (data) {
      swal("NOW!", response, "error");


    }

  })

})

$("#billform").on("change", "select.employee", function () {
  let employee = $(this).val();
  console.log("name", employee);
  fill_salary(employee);

})


$("#employee").on("change", function(){
  if($("#employee").val()== 0){
    console.log("0 waaye");
    $("#amount").val("");

  }else{
    console.log(amount);
  }
})


function fill_salary(employee) {
  let sendingData = {
    "action": "read_employe_salary",
    "employee": employee

  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/bils.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      console.log("name", response)
      let html = '';
      let tr = '';

      if (status) {

        response.forEach(res => {
          $("#amount").val(res['salary']);

        })



      } else {
        displaymessage("error", response);
      }

    },
    error: function (data) {

    }

  })
}


function loadbills() {
  $("#billsTable tbody").html('');
  $("#billsTable thead").html('');

  let sendingData = {
    "action": "read_bills"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/bils.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';
      let th = '';

      if (status) {
        response.forEach(res => {
          th = "<tr>";
          for (let r in res) {
            th += `<th>${r}</th>`;
          }





          tr += "<tr>";
          for (let r in res) {


            if(r=="salary"){
              tr += `<td>$${res[r]}</td>`;

            }else{
              tr += `<td>${res[r]}</td>`;

            }


          }

          tr += "</tr>"

        })
        $("#billsTable thead").append(th);
        $("#billsTable tbody").append(tr);
      }



    },
    error: function (data) {

    }

  })
}

