loademedicine();

btnAction = "Insert";


$("#medicineform").on("submit", function (event) {

  event.preventDefault();


  let medicine_name = $("#medicine_name").val();
  let manufacturer = $("#manufacturer").val();
  let price = $("#price").val();
  let id = $("#update_id").val();

  let sendingData = {}

  if (btnAction == "Insert") {
    sendingData = {
      "medicine_name": medicine_name,
      "manufacturer": manufacturer,
      "price": price,
      "action": "register_medicine"
    }

  } else {
    sendingData = {
      "medicine_id": id,
      "medicine_name": medicine_name,
      "manufacturer": manufacturer,
      "price": price,
      "action": "update_medicine"
    }
  }



  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/medicine.php",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        swal("Good job!", response, "success");
        btnAction = "Insert";
        loademedicine();
        $("#medicineform")[0].reset();
        $("#medicinemodal").modal("hide");
        






      } else {
        swal("NOW!", response, "error");

  
      }

    },
    error: function (data) {
      swal("NOW!", response, "error");


    }

  })

})


function loademedicine() {
  $("#medicinetable tbody").html('');
  $("#medicinetable thead").html('');

  let sendingData = {
    "action": "read_all_medicine"
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/medicine.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;
      let html = '';
      let tr = '';
      let th = '';

      if (status) {
        response.forEach(res => {
          th = "<tr>";
          for (let r in res) {
            th += `<th>${r}</th>`;
          }

          th += "<td>Action</td></tr>";




          tr += "<tr>";
          for (let r in res) {


            tr += `<td>${res[r]}</td>`;


          }

          tr += `<td <div class="dropdown">
          <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
              <i class="bx bx-dots-vertical-rounded"></i>
          </button>
          <div class="dropdown-menu">
              <a class="dropdown-item  update_info" href="javascript:void(0);" update_id=${res['medicine_id']}><i class="bx bx-edit-alt me-1"></i> Edit</a>
              <a class="dropdown-item delete_info" href="javascript:void(0);" delete_id=${res['medicine_id']}><i class="bx bx-trash me-1"></i> Delete</a>
          </div>
      </div></td>`
          tr += "</tr>"

          // tr += `<td> <a class="btn btn-info update_info"  update_id=${res['Account_id']}><i class="mdi mdi-grease-pencil" style="color: #fff"></i></a>&nbsp;&nbsp <a class="btn btn-danger delete_info" delete_id=${res['Account_id']}><i class="mdi mdi-close-box
          // " style="color: #fff"></i></a> </td>`
          // tr += "</tr>"

        })
        $("#medicinetable thead").append(th);
        $("#medicinetable tbody").append(tr);
      }


    },
    error: function (data) {

    }

  })
}

function get_medicine_info(medicine_id) {

  let sendingData = {
    "action": "get_medicine_info",
    "medicine_id": medicine_id
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/medicine.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;


      if (status) {

        btnAction = "update";

        $("#update_id").val(response['medicine_id']);
        $("#medicine_name").val(response['medicine_name']);
        $("#manufacturer").val(response['manufacturer']);
        $("#price").val(response['price']);
        $("#medicinemodal").modal('show');




      } else {
        dispalaymessage("error", response);
      }

    },
    error: function (data) {

    }

  })
}

function Delete_medicine(medicine_id) {

  let sendingData = {
    "action": "Delete_medicine",
    "medicine_id": medicine_id
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/medicine.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;


      if (status) {

        swal("Good job!", response, "success");
        loademedicine();


      } else {
        swal("NOW!", response, "error");

      
      }

    },
    error: function (data) {

    }

  })
}

$("#medicinetable").on('click', "a.update_info", function () {
  let id = $(this).attr("update_id");
  get_medicine_info(id)
})


$("#medicinetable").on('click', "a.delete_info", function () {
  let id = $(this).attr("delete_id");
  if (confirm("Are you sure To Delete")) {
    Delete_medicine(id)

  }

})