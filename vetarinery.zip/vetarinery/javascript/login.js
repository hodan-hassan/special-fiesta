//  alert("hello");
$("#loginForm").on("submit", function (e) {

  e.preventDefault();
  let username = $("#username").val();
  let password = $("#password").val();


  let sendingData = {
    "action": "login",
    "username": username,
    "password": password
  }

  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "Api/Login.php",
    data: sendingData,

    success: function (data) {
      let status = data.status;
      let response = data.data;


      if (status) {
        window.location.href = "index.php";

      } else {
        displayMessage("error",response);
         $("#username").val("");
        $("#password").val("");
      }

    },
    error: function (data) {
      

    }

  })

})



function displayMessage(type,message){

  let success = document.querySelector(".alert-success");
  let error = document.querySelector(".alert-danger");

  if(type == "success"){
      error.classList = "alert alert-danger d-none";
      success.classList = "alert alert-success";
      success.innerHTML = message;

      setTimeout(function(){
          success.classList = "alert alert-success d-none";
      },400);


  }else{
      error.classList = "alert alert-danger";
      error.innerHTML = message;
  }

}
